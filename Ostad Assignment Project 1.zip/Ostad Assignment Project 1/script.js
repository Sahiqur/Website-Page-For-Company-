const plus= document.querySelector(".btn-plus"),
minus=document.querySelector(".btn-minus"),
number=document.querySelector(".btn-number"),
room=document.querySelector(".btn-room");


let a=199;
let r=1 ;

plus.addEventListener("click",()=>{
  a=a+199;
  r=r+1;
  number.innerHTML=a;
  room.innerHTML=r;

document.getElementById("cursore-sign").innerHTML="$"+" "+a;
document.getElementById("cursore1").innerHTML=r+" "+"room";


})

minus.addEventListener("click",()=>{
   if(a>199 && r>1){
    a=a-199;
    r=r-1;
    number.innerHTML=a;
    room.innerHTML=r;
   }
    
   document.getElementById("cursore-sign").innerHTML="$"+" "+a;
  document.getElementById("cursore1").innerHTML=r+" "+"room"
  })

  function myFunction() {
    r=r+1
    room.innerHTML=r;
    document.getElementById("msg").innerHTML = "Thank You For Chossing"+" "+r+" "+" Room";
    document.getElementById("cursore1").innerHTML=r+" "+"room"
  }

  function myFunction() {
    if(r>1){
      room.innerHTML=r;
    }
    
    document.getElementById("msg").innerHTML = "Thank You For Chossing"+" "+r+" "+" Room";
    document.getElementById("cursore1").innerHTML=r+" "+"room"
  }





  
  
//right side Increasing and Decreasing part 

const plus1= document.querySelector(".right-plus"),
minus1=document.querySelector(".right-minus"),
number1=document.querySelector(".right-number"),
room1=document.querySelector(".right-room");

let b=249;
let r1=1;
plus1.addEventListener("click",()=>{
    b=b+249;
    r1=r1+1;
    number1.innerHTML=b;
    room1.innerHTML=r1;
  
  document.getElementById("cursore-right-sign").innerHTML="$"+" "+b;
  document.getElementById("cursore-r").innerHTML=r1+" "+"room"
 
  })

  minus1.addEventListener("click",()=>{
     if(b>249 && r1>1){
        b=b-249
        r1=r1-1;
        number1.innerHTML=b;
        room1.innerHTML=r1;
     }
    
    
    document.getElementById("cursore-right-sign").innerHTML="$"+" "+b;
    document.getElementById("cursore-r").innerHTML=r1+" "+"room";
  })


  function myProgram() {
     r1=r1+1;

     room1.innerHTML=r1;

    document.getElementById("msg1").innerHTML = "Thank You For Chossing"+" "+r1+" "+" Room";
    document.getElementById("cursore-r").innerHTML=r1+" "+"room";
  }


  function myProgram() {
    if(r1>1){
      room1.innerHTML=r1;
    }

    

   document.getElementById("msg1").innerHTML = "Thank You For Chossing"+" "+r1+" "+" Room";
   document.getElementById("cursore-r").innerHTML=r1+" "+"room";
 }